/** Automatically generated file. DO NOT MODIFY */
package com.example.demo_bg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}