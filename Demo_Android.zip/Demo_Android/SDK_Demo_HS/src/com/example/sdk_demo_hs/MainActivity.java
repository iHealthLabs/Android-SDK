package com.example.sdk_demo_hs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.jiuan.android.sdk.hs.bluetooth.HSCommManager;
import com.jiuan.android.sdk.hs.bluetooth.HS3Control;
import com.jiuan.android.sdk.hs.bluetooth.HS5Control;
import com.jiuan.android.sdk.hs.bluetooth.Hs4sControls;
import com.jiuan.android.sdk.hs.bluetooth.lpcbt.Control;
import com.jiuan.android.sdk.hs.observer_comm.Interface_Observer_CommMsg_HS;
import com.jiuan.android.sdk.hs.wifi.HS5WiFiControl;
import com.jiuan.android.sdk.hs.wifi.WiFiCommManager;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class MainActivity extends Activity implements Interface_Observer_CommMsg_HS{

	private String TAG = "MainActivity";
	
	private HSCommManager btCommManager;
	private WiFiCommManager wifiCommManager;
	
	private ListView hslist;
	private SimpleAdapter sa;
	private List<HashMap<String,String>> list;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		btCommManager = HSCommManager.getInstance();
		btCommManager.init(MainActivity.this);
		btCommManager.msgSubject.attach(this);
		
		wifiCommManager = WiFiCommManager.getInstance();
		wifiCommManager.init(MainActivity.this);
		wifiCommManager.msgSubject.attach(this);
		
		hslist = (ListView)findViewById(R.id.listView_HS);
		initReceiver();
	}

	private void initReceiver() {
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Hs4sControls.MSG_HS4S_CONNECTED);
		registerReceiver(mReceiver, intentFilter);
	}
	
	private void unReceiver(){
		unregisterReceiver(mReceiver);
	}
	
	BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(Hs4sControls.MSG_HS4S_CONNECTED.equals(action)){
            	Message message = new Message();
            	message.what = 1;
            	handler.sendMessage(message);	
            }
        }
    };
	
	private void refreshListView(){
		list = new ArrayList<HashMap<String, String>>();
		list.clear();
		//HS3--BT
		Set<HashMap.Entry<BluetoothDevice, HS3Control>> set3 = HSCommManager.mapHS3DeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, HS3Control>> it = set3.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, HS3Control> entry = (Map.Entry<BluetoothDevice, HS3Control>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "HS3");
			map.put("address", entry.getKey().getAddress());
			list.add(map);
		}
		//HS4
		Set<HashMap.Entry<String, Control>> set4 = btCommManager.getmapHS4DeviceConnected().entrySet();
		for (Iterator<Map.Entry<String, Control>> it = set4.iterator(); it.hasNext();) {
			Map.Entry<String, Control> entry = (Map.Entry<String, Control>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "HS4");
			map.put("address", entry.getKey());
			list.add(map);
		}
		// HS4S
		Set<HashMap.Entry<BluetoothDevice, Hs4sControls>> set4s = HSCommManager.mapHS4SDeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, Hs4sControls>> it = set4s.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, Hs4sControls> entry = (Map.Entry<BluetoothDevice, Hs4sControls>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "HS4S");
			map.put("address", entry.getKey().getAddress());
			list.add(map);
		}
		//HS5--BT
		Set<HashMap.Entry<BluetoothDevice, HS5Control>> set5 = HSCommManager.mapHS5DeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, HS5Control>> it = set5.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, HS5Control> entry = (Map.Entry<BluetoothDevice, HS5Control>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "HS5-BT");
			map.put("address", entry.getKey().getAddress());
			list.add(map);
		}
		//HS5--WIFI
		Set<HashMap.Entry<String, HS5WiFiControl>> set5s = WiFiCommManager.mapHS5Online.entrySet();
		for (Iterator<Map.Entry<String, HS5WiFiControl>> it = set5s.iterator(); it.hasNext();) {
			Map.Entry<String, HS5WiFiControl> entry = (Map.Entry<String, HS5WiFiControl>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "HS5-WiFi");
			map.put("address", entry.getKey());
			list.add(map);
		}
		if(list != null){
			sa = new SimpleAdapter(this, list, R.layout.item_listview, 
					new String[]{"name", "address"},
					new int[]{R.id.hsname, R.id.hsaddress});
			hslist.setAdapter(sa);
			hslist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					if(list.get(position).get("name").equals("HS3")){
						Log.i(TAG, "HS3");
						Intent it = new Intent(MainActivity.this,Hs3Activity.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
					if(list.get(position).get("name").equals("HS4")){
						Log.i(TAG, "HS4");
						Intent it = new Intent(MainActivity.this,Hs4Activity.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						Log.e(TAG, "HS4MAC=" + list.get(position).get("address"));
						startActivity(it);
					}
					if(list.get(position).get("name").equals("HS4S")){
						Log.i(TAG, "HS4S");
						Intent it = new Intent(MainActivity.this,Hs4sActivity.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						Log.e(TAG, "HS4SMAC=" + list.get(position).get("address"));
						startActivity(it);
					}
					if(list.get(position).get("name").equals("HS5-BT")){
						Log.i(TAG, "HS5-BT");
						Intent it = new Intent(MainActivity.this,Hs5Activity_bt.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
					if(list.get(position).get("name").equals("HS5-WiFi")){
						Log.i(TAG, "HS5-WiFi");
						Intent it = new Intent(MainActivity.this,Hs5Activity_wifi.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
				}
			});
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		refreshListView();
		
	}
	@Override
	public void msgDeviceConnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"connect "+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}

	@Override
	public void msgDeviceDisconnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"disconnect "+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}
	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				refreshListView();
				break;
			default:
				break;
			}
		}

	};
	@Override
	protected void onStop() {
		super.onStop();

	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unReceiver();
		btCommManager.stop();
		wifiCommManager.stop();
		System.exit(0);
	}

}
