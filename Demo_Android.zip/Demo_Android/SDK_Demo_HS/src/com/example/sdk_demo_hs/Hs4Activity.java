package com.example.sdk_demo_hs;

import com.jiuan.android.sdk.hs.bluetooth.HSCommManager;
import com.jiuan.android.sdk.hs.bluetooth.lpcbt.HS4Control;
import com.jiuan.android.sdk.hs.bluetooth.lpcbt.JiuanHS4Observer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Hs4Activity extends Activity implements JiuanHS4Observer{

	private String TAG = "Hs4Activity";
	private Button connect, measure, history;
	private HS4Control hs4Control = null;
	private HSCommManager btCommManager;
	private String deviceMac = "";
	private TextView tv_msg ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hs4);
		
		btCommManager = HSCommManager.getInstance();
		Intent intent = getIntent();
		deviceMac = intent.getStringExtra("testDevice");

		hs4Control = (HS4Control) (btCommManager.getmapHS4DeviceConnected()).get(deviceMac);
		hs4Control.addObserver(this);
		
		history = (Button) findViewById(R.id.history);
		measure = (Button) findViewById(R.id.online);
		connect = (Button)findViewById(R.id.connect);
		
		connect.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String userId = "";
				final String clientID = "";
				final String clientSecret = "";
				hs4Control.connect(Hs4Activity.this,userId,clientID,clientSecret);
			}
		});
		
		history.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(hs4Control!=null){
					new Thread() {
						@Override
						public void run() {
							hs4Control.getOfflineData();
						}

					}.start();
				}
			}
		});
		
		measure.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(hs4Control!=null){
					new Thread() {
						@Override
						public void run() {
							hs4Control.startMeasure();
						}

					}.start();
				}
			}
		});

		tv_msg = (TextView)findViewById(R.id.content);
		
	}

	@Override
	public void msgUserStatus(int status) {
		// TODO Auto-generated method stub
		Log.e(TAG, "user status:" + status);
		Message message = new Message();
		message.what = 1;
		Bundle bundle = new Bundle();
		bundle.putInt("status",status);
		message.obj = bundle;
		handler.sendMessage(message);
	}
	
	@Override
	public void msgOffLineData_HS4(String offlineData) {
		// TODO Auto-generated method stub
		Log.e(TAG, "offline data:" + offlineData);
		Message message = new Message();
		message.what = 2;
		Bundle bundle = new Bundle();
		bundle.putString("data",offlineData);
		message.obj = bundle;
		handler.sendMessage(message);
	}
	
	@Override
	public void msgCurrentData_HS4(float weight) {
		// TODO Auto-generated method stub
		Log.e(TAG, "realWeight" + weight);
		Message message = new Message();
		message.what = 3;
		Bundle bundle = new Bundle();
		bundle.putFloat("weight",weight);
		message.obj = bundle;
		handler.sendMessage(message);
	}
	
	@Override
	public void msgOnLineData_HS4(float weight) {
		// TODO Auto-generated method stub
		Log.e(TAG, "stabWeight" + weight);
		Message message = new Message();
		message.what = 4;
		Bundle bundle = new Bundle();
		bundle.putFloat("weight",weight);
		message.obj = bundle;
		handler.sendMessage(message);
	}

	/**
	 * UI handler
	 */
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				Bundle bundle1 = (Bundle)msg.obj;
				int status = bundle1.getInt("status");
				tv_msg.setText("user status:"+status);
				break;
			case 2:
				Bundle bundle2 = (Bundle)msg.obj;
				String data = bundle2.getString("data");
				tv_msg.setText("offline data："+data);
				break;
			case 3:
				Bundle bundle3 = (Bundle)msg.obj;
				Float result0 = bundle3.getFloat("weight");
				tv_msg.setText("real weight："+result0);
				break;
			case 4:
				Bundle bundle4 = (Bundle)msg.obj;
				Float result1 = bundle4.getFloat("weight");
				tv_msg.setText("result："+result1);
				break;
			default:
				break;
			}
		}
	};
	public String Bytes2HexString(byte[] b) {
		String ret = "";
		for (int i = 0; i < b.length; i++) {
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			ret += hex.toUpperCase();
		}
		return ret;
	}

}
