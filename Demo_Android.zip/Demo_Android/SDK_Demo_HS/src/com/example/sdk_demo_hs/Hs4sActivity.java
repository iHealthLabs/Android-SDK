package com.example.sdk_demo_hs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.jiuan.android.sdk.hs.bluetooth.HSCommManager;
import com.jiuan.android.sdk.hs.bluetooth.Hs4sControls;

public class Hs4sActivity extends Activity{

	private Button connect, measure, history;
	private Hs4sControls mHs4sControl = null;
	private HSCommManager btCommManager;
	private String deviceMac = "";
	private TextView tv_msg ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hs4);
		initReceiver();
		btCommManager = HSCommManager.getInstance();
		Intent intent = getIntent();
		deviceMac = intent.getStringExtra("testDevice");
//		for (Entry<BluetoothDevice, Hs4sControls> entry : HSCommManager.mapHS4SDeviceConnected.entrySet()) {
//			if(entry.getKey().getAddress().equals(deviceMac)){
//				mHs4sControl = entry.getValue();
//			}
//		}
		
		Set<HashMap.Entry<BluetoothDevice, Hs4sControls>> set4s = HSCommManager.mapHS4SDeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, Hs4sControls>> it = set4s.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, Hs4sControls> entry = (Map.Entry<BluetoothDevice, Hs4sControls>) it.next();
			if(entry.getKey().getAddress().equals(deviceMac)){
				mHs4sControl = entry.getValue();
			}
		}
		
		history = (Button) findViewById(R.id.history);
		measure = (Button) findViewById(R.id.online);
		connect = (Button)findViewById(R.id.connect);
		
		connect.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String userId = "";
				final String clientID = "";
				final String clientSecret = "";
				btCommManager.stopBluetoothScan();
				mHs4sControl.connect(Hs4sActivity.this,userId,clientID,clientSecret);
			}
		});
		
		history.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mHs4sControl!=null)
					mHs4sControl.getOfflineData();
			}
		});
		
		measure.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mHs4sControl!=null)
					mHs4sControl.startMeasure();
			}
		});

		tv_msg = (TextView)findViewById(R.id.content);
	}

	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unReceiver();
	}

	private void initReceiver() {
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Hs4sControls.MSG_HS4S_USER_DATA);
		intentFilter.addAction(Hs4sControls.MSG_HS4S_OFFLINE_DATA);
		intentFilter.addAction(Hs4sControls.MSG_HS4S_REALTIME_DATA);
		intentFilter.addAction(Hs4sControls.MSG_HS4S_RESULT_DATA);
		registerReceiver(mReceiver, intentFilter);
	}
	
	private void unReceiver(){
		unregisterReceiver(mReceiver);
	}
	
	BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(Hs4sControls.MSG_HS4S_USER_DATA.equals(action)){
            	int status = intent.getIntExtra(Hs4sControls.MSG_HS4S_USER_DATA_EXTRA, 0);
            	tv_msg.setText("user status:" + status);
            	Log.i("", "user status:" + status);
            }else if(Hs4sControls.MSG_HS4S_OFFLINE_DATA.equals(action)){
            	String offline = intent.getStringExtra(Hs4sControls.MSG_HS4S_OFFLINE_DATA_EXTRA);
            	tv_msg.setText("offline data：" + offline);
            	Log.i("", "offline data：" + offline);
            }else if(Hs4sControls.MSG_HS4S_REALTIME_DATA.equals(action)){
            	int real = intent.getIntExtra(Hs4sControls.MSG_HS4S_REALTIME_DATA_EXTRA, 0);
            	tv_msg.setText("real weight：" + real);
            	Log.i("", "real weight：" + real);
            }else if(Hs4sControls.MSG_HS4S_RESULT_DATA.equals(action)){
            	int result = intent.getIntExtra(Hs4sControls.MSG_HS4S_RESULT_DATA_EXTRA, 0);
            	tv_msg.setText("result："+result);
            	Log.i("", "result："+result);
            }
        }
    };

}
