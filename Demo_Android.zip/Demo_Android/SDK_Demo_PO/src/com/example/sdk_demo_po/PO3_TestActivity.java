
package com.example.sdk_demo_po;

import com.example.sdk_demo_po.R;

import jiuan.androidPO.bluetooth.BTCommManager;
import jiuan.androidnin1.bluetooth.lpcbt.JiuanPO3Observer;
import jiuan.androidnin1.bluetooth.lpcbt.PO3Control;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class PO3_TestActivity extends Activity implements JiuanPO3Observer {

    private BTCommManager deviceManager;
    private String mac = "";
    private PO3Control poControl;

    private Button btn_connect;
    private Button btn_bettary;
    private Button btn_history, btn_realdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_po3);

        // get control by device mac
        deviceManager = BTCommManager.getInstance();
        mac = ((Bundle) (getIntent().getExtras())).getString("testDevice").replace(":", "");
        poControl = (PO3Control) (deviceManager.getmap40DeviceConnected()).get(mac);
        if (poControl != null) {
            poControl.addObserver(this);
        }

        initView();
    }

    private void initView() {
        btn_connect = (Button) findViewById(R.id.connect);
        btn_connect.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                /**
                 * userId, the identification of the user, could be the form of email address or
                 * mobile phone number (mobile phone number is not supported temporarily). clientID
                 * and clientSecret, as the identification of the SDK, will be issued after the
                 * iHealth SDK registration. please contact lvjincan@jiuan.com for registration.
                 */
                String userId = "liu01234345555@jiuan.com";
                final String clientID = "2a8387e3f4e94407a3a767a72dfd52ea";
                final String clientSecret = "fd5e845c47944a818bc511fb7edb0a77";
                poControl.connect(PO3_TestActivity.this, userId, clientID, clientSecret);
            }
        });

        btn_bettary = (Button) findViewById(R.id.bettary);
        btn_bettary.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                poControl.getBattery();
            }
        });
        btn_history = (Button) findViewById(R.id.history);
        btn_history.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                poControl.syncHistoryDatas();
            }
        });
        btn_realdata = (Button) findViewById(R.id.realdata);
        btn_realdata.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                deviceManager.stopBluetoothScan(); // 用户进行测量测量过程中，停止低功耗蓝牙扫描
                poControl.startRealTime();
            }
        });

    }

    private Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    int userStatus = ((Bundle) (msg.obj)).getInt("status");
                    Toast.makeText(getApplicationContext(), "PO3 UserStatus=" + userStatus, Toast.LENGTH_SHORT).show();
                    break;
                case 1:
                    int battery = ((Bundle) (msg.obj)).getInt("battery");
                    Toast.makeText(getApplicationContext(), "PO3 battery=" + battery, Toast.LENGTH_SHORT).show();
                    break;
                case 2:
                    String historyData = ((Bundle) (msg.obj)).getString("historyData");
                    Toast.makeText(getApplicationContext(), "PO3 historyData=" + historyData, Toast.LENGTH_SHORT)
                            .show();
                    break;
                case 3:
                    String result = ((Bundle) (msg.obj)).getString("result");
                    Toast.makeText(getApplicationContext(), "PO3 result=" + result, Toast.LENGTH_SHORT).show();
                    break;
                case 4:

                    Toast.makeText(getApplicationContext(), "no historyData", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }

    };

    @Override
    public void msgUserStatus(int status) {
        // TODO Auto-generated method stub
        Log.i("act", "user status" + status);
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putInt("status", status);
        msg.what = 0;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }

    @Override
    public void msgBattery(int battery) {
        // TODO Auto-generated method stub
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putInt("battery", battery);
        msg.what = 1;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }

    @Override
    public void msgHistroyData(String historyData) {
        // TODO Auto-generated method stub
        if (historyData == null) {
            Log.d("history", "no historyData");
            handler.sendEmptyMessage(4);
            /**
             * There is no historical data
             */
        } else {
            Log.i("history", historyData);
            Message msg = new Message();
            Bundle bundle = new Bundle();
            bundle.putString("historyData", historyData);
            msg.what = 2;
            msg.obj = bundle;
            handler.sendMessage(msg);
        }
    }

    @Override
    public void msgRealtimeData(String realData) {
        // TODO Auto-generated method stub
        Log.i("real", realData);
    }

    @Override
    public void msgResultData(String result) {
        // TODO Auto-generated method stub
        Log.i("end", result);
        deviceManager.resumeBluetoothScan(); // 恢复低功耗蓝牙扫描
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putString("result", result);
        msg.what = 3;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }

}
