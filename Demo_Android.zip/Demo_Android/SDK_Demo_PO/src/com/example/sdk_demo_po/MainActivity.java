package com.example.sdk_demo_po;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.example.sdk_demo_po.R;

import jiuan.androidPO.Bean.POMethod;
import jiuan.androidPO.ObserverComm.Interface_Observer_CommMsg;
import jiuan.androidPO.bluetooth.BTCommManager;
import jiuan.androidnin1.bluetooth.lpcbt.Control;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class MainActivity extends Activity implements Interface_Observer_CommMsg{

	private String TAG = "MainActivity";

	private BTCommManager btCommManager;

	private ListView devicelist;
	private SimpleAdapter sa;
	private List<HashMap<String,String>>  list;

	private Button btn_test;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btCommManager = BTCommManager.getInstance();
		btCommManager.init(MainActivity.this);		
		btCommManager.msgSubject.attach(this);
		//		
		btn_test = (Button)findViewById(R.id.btn_test);
		btn_test.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new Thread(){
					public void run(){
						Log.i("",POMethod.downloadSyncTime(MainActivity.this, "1234567890123456")+"");
					}
				}.start();
//				byte[] data = new byte[]{
//						(byte)0x0E,(byte)0x09,(byte)0x0F,(byte)0x11,(byte)0x24,(byte)0x30,
//						(byte)0x01,
//						(byte)0x61,
//						(byte)0x4E,
//						(byte)0x0B,(byte)0x02,(byte)0x96,(byte)0x01,(byte)0xFE,(byte)0x01,(byte)0xC3,(byte)0x03,(byte)0x62,(byte)0x06,
//						(byte)0xA0,(byte)0x08,(byte)0xC7,(byte)0x09,(byte)0x2A,(byte)0x0A,(byte)0x2C,(byte)0x0A,(byte)0x43,(byte)0x08,
//						(byte)0xA5,(byte)0x07,(byte)0x0F,(byte)0x07,(byte)0xBE,(byte)0x06,(byte)0xA1,(byte)0x06,(byte)0x6D,(byte)0x06,
//						(byte)0x05,(byte)0x06,(byte)0x76,(byte)0x05,(byte)0xD0,(byte)0x04,(byte)0x29,(byte)0x04,(byte)0x7C,(byte)0x03,
//						(byte)0xE1,(byte)0x02,(byte)0x59,(byte)0x02,(byte)0xDB,(byte)0x01,(byte)0x5E,(byte)0x01,(byte)0xCD,(byte)0x00,
//						(byte)0x36,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x7D,(byte)0x00,(byte)0x9F,(byte)0x02,(byte)0x84,(byte)0x05,
//						(byte)0xCA,(byte)0x07,(byte)0xD1,(byte)0x08,(byte)0xFA,(byte)0x08,(byte)0xEE,(byte)0x08,(byte)0x5F,(byte)0x08,
//						(byte)0xAE,(byte)0x07,(byte)0x1A,(byte)0x07,(byte)0xED,(byte)0x06,(byte)0xFC,(byte)0x06,(byte)0xFB,(byte)0x06
//				};
//				POMethod.changeOfflineData2JSON(data);
//				byte[] data = new byte[]{
//						(byte)0x61,(byte)0x4B,(byte)0x02,(byte)0x1C,(byte)0x0B,(byte)0x98,(byte)0x72,(byte)0x03,(byte)0x09,(byte)0x46,(byte)0x08,(byte)0x00,(byte)0x00	
//				};
//				POMethod.changeData2JSON(data);
			}
		});
		btn_test.setVisibility(View.GONE);
		devicelist = (ListView)findViewById(R.id.listView);

	}

	private void refreshListView(){
		list = new ArrayList<HashMap<String, String>>();
		list.clear();
		Set<HashMap.Entry<String, Control>> set = btCommManager.getmap40DeviceConnected().entrySet();
		for (Iterator<Map.Entry<String, Control>> it = set.iterator(); it.hasNext();) {
			Map.Entry<String, Control> entry = (Map.Entry<String, Control>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			//
			map.put("name", "Pulse");
			map.put("address", entry.getKey());
			list.add(map);
		}
		if(list != null){
			sa = new SimpleAdapter(this, list, R.layout.item_listview, 
					new String[]{"name", "address"},
					new int[]{R.id.hsname, R.id.hsaddress});
			devicelist.setAdapter(sa);
			devicelist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					if(list.get(position).get("name").equals("Pulse")){
						Log.i(TAG, "Pluse");
						Intent it = new Intent(MainActivity.this,PO3_TestActivity.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
				}
			});
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		refreshListView();

	}
	@Override
	public void msgDeviceConnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"连接上"+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}

	@Override
	public void msgDeviceDisconnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"断开了"+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}
	private Handler handler = new Handler(){
		//UI更新
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				refreshListView();
				break;
			default:
				break;
			}
		}

	};
	@Override
	protected void onStop() {
		super.onStop();

	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		btCommManager.disconnectDevice();
		System.exit(0);
	}

}
