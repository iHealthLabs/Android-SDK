package com.example.sdk_demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import jiuan.android.sdk.BP.bluetooth.BPCommManager;
import jiuan.android.sdk.BP.bluetooth.BPControl;
import jiuan.android.sdk.BP.bluetooth.manager.BPDeviceManager;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.jiuan.Demo_BP.R;

public class MainActivity extends Activity{

	private ListView bplist;
	private BPCommManager myComm;//bp5 bp7
	private List<HashMap<String,String>>  list;
	private SimpleAdapter sa;
	private BluetoothAdapter myAdapter;
	private Button bt_test;
	private Button btn_abiDevice;
	private String userId = "";
	private BPDeviceManager dm = BPDeviceManager.getInstance();//bp3
	
	private Timer timer;
    private TimerTask btTask;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
		bplist = (ListView) findViewById(R.id.bplist);
		/**
		 * the identification of the user, 
		 * could be the form of email address or mobile phone number
		 * (mobile phone number is not supported temporarily)
		 */
		userId = "";
		myComm = new BPCommManager(MainActivity.this,userId);
		myAdapter = BluetoothAdapter.getDefaultAdapter();
		buletooth_timer();
		bt_test = (Button)findViewById(R.id.button_test);
		bt_test.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						Message message = new Message();
						message.what = 1;
						handler.sendMessage(message);
					}
				}).start();
			}
		});
		btn_abiDevice = (Button) findViewById(R.id.abi_enter);
		btn_abiDevice.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(BPCommManager.abiControl != null){
					Intent intent = new Intent(MainActivity.this, ABI_Activity.class);
					startActivity(intent);
				} else {
					Log.e("", "wait for connecting");       		
				}

			}
		});
		dm.initDeviceManager(userId,MainActivity.this);
		dm.initUsbCommHost();
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED);
		intentFilter.addAction(android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		intentFilter.addAction(BluetoothDevice.ACTION_FOUND);
		intentFilter.addAction(android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		this.registerReceiver(BluetoothReceiver, intentFilter);
	}

	private void getNameList() {
		list = new ArrayList<HashMap<String, String>>();
		Set<HashMap.Entry<BluetoothDevice, BPControl>> set = BPCommManager.mapBPDeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, BPControl>> it = set
				.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, BPControl> entry = (Map.Entry<BluetoothDevice, BPControl>) it
					.next();
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", entry.getKey().getName());
			map.put("address", entry.getKey().getAddress());
			list.add(map);
		}

		if(dm.getUsbControlForBP() != null){
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("name", "BP3");
			map.put("address", "000001");
			list.add(map);
		}
	}

	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				getNameList();
				initView();
				break;

			default:
				break;
			}
		}

	};

	private void initView(){
		if(list.size() > 0){
			sa = new SimpleAdapter(this, list, R.layout.bp_listview_baseview, 
					new String[]{"name", "address"},
					new int[]{R.id.bpname, R.id.bpaddress});
			bplist.setAdapter(sa);
			bplist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					// TODO Auto-generated method stub
					if(dm.getUsbControlForBP() != null){
						Intent intent = new Intent(MainActivity.this, BP3_Activity.class);
						startActivity(intent);
						return;
					}

					Set<HashMap.Entry<BluetoothDevice, BPControl>> set = BPCommManager.mapBPDeviceConnected.entrySet();
					for (Iterator<Map.Entry<BluetoothDevice, BPControl>> it = set.iterator(); it.hasNext();) {
						Map.Entry<BluetoothDevice, BPControl> entry = (Map.Entry<BluetoothDevice, BPControl>) it.next();
						if (entry.getKey().getName().equals(list.get(position).get("name"))) {
							BPCommManager.testDevice = entry.getKey();
							break;
						}
					}

					if(BPCommManager.testDevice.getName().contains("BP5")){//bp5
						Intent intent = new Intent(MainActivity.this, BP5_Activity.class);
						startActivity(intent);
					}else if(BPCommManager.testDevice.getName().contains("BP7")){//bp7
						Intent intent = new Intent(MainActivity.this, BP7_Activity.class);
						startActivity(intent);
					}
				}
			});
		}
	}

	private BroadcastReceiver BluetoothReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			String action = intent.getAction();
			if (action.equals(android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_STARTED)){
				Log.i("", "start discovery");
			}
			if (BluetoothDevice.ACTION_FOUND.equals(action)) {
				final BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				Log.i("", "find device:" + device.getName() +"--"+ device.getAddress());
				if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
					Log.e("","device was bonded");
					myAdapter.cancelDiscovery();
					myComm.startConnect(device);
				}else{
					Log.i("","device was not bonded");
				}
			}
			if (action.equals(android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_FINISHED)){
				Log.i("", "discovery end");

			}
		}
	};
	//	public static boolean isConnect = false;
	public void buletooth_timer() {
		timer = new Timer();
		btTask = new TimerTask() {
			public void run() {
				// TODO Auto-generated method stub
				//				if(!isConnect){
				myAdapter.startDiscovery();					
				//				}
				Log.i("MainActivity", "startDiscovery");
			}
		};

		try {
			timer.schedule(btTask, 500, 5000);
		} catch (IllegalStateException e) {
			e.printStackTrace();
			Log.e("aa", "IllegalStateException");
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			Log.e("aa", "IllegalArgumentException");
		}
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.i("life", "onDestroy");
		if(timer != null){
		    timer.cancel();
		    btTask.cancel();
		}
		myAdapter.cancelDiscovery();
		unregisterReceiver(BluetoothReceiver);
		Set<HashMap.Entry<BluetoothDevice, BPControl>> set = BPCommManager.mapBPDeviceConnected.entrySet();
		for (Iterator<Map.Entry<BluetoothDevice, BPControl>> it = set.iterator(); it.hasNext();) {
			Map.Entry<BluetoothDevice, BPControl> entry = (Map.Entry<BluetoothDevice, BPControl>) it.next();
			entry.getValue().stop();
		}
		
		System.exit(0);
	}
}
