/** Automatically generated file. DO NOT MODIFY */
package com.jiuan.Demo_BP;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}