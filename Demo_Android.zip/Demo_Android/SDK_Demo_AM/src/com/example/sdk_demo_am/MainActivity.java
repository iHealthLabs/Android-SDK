package com.example.sdk_demo_am;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jiuan.androidAM.ObserverComm.Interface_Observer_CommMsg;
import jiuan.androidAM.bluetooth.BTCommManager;
import jiuan.androidnin1.bluetooth.lpcbt.Control;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class MainActivity extends Activity implements Interface_Observer_CommMsg{

	private boolean Debug = true;
	private String TAG = "MainActivity";

	private BTCommManager btCommManager;

	private ListView hslist;
	private SimpleAdapter sa;
	private List<HashMap<String,String>>  list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btCommManager = BTCommManager.getInstance();
		btCommManager.init(MainActivity.this);		
		btCommManager.msgSubject.attach(this);
		//		

		hslist = (ListView)findViewById(R.id.listView_HS);

	}

	private void refreshListView(){
		list = new ArrayList<HashMap<String, String>>();
		list.clear();
		Set<HashMap.Entry<String, Control>> set = btCommManager.getmap40DeviceConnected().entrySet();
		for (Iterator<Map.Entry<String, Control>> it = set.iterator(); it.hasNext();) {
			Map.Entry<String, Control> entry = (Map.Entry<String, Control>) it.next();
			HashMap<String, String> map = new HashMap<String, String>();
			//
			if(entry.getValue().getDevice().getName().contains("AM3S")){
				map.put("name", "AM3S");
			}else if(entry.getValue().getDevice().getName().contains("Activity")){
				map.put("name", "AM3");
			}
			map.put("address", entry.getKey());
			list.add(map);
		}
		if(list != null){
			sa = new SimpleAdapter(this, list, R.layout.item_listview, 
					new String[]{"name", "address"},
					new int[]{R.id.hsname, R.id.hsaddress});
			hslist.setAdapter(sa);
			hslist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					if(list.get(position).get("name").equals("AM3")){
						Log.i(TAG, "AM3");
						Intent it = new Intent(MainActivity.this,AM3_Test.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
					if(list.get(position).get("name").equals("AM3S")){
						Log.i(TAG, "AM3S");
						Intent it = new Intent(MainActivity.this,AM3S_Test.class);
						it.putExtra("testDevice", list.get(position).get("address"));
						startActivity(it);
					}
				}
			});
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		refreshListView();

	}
	@Override
	public void msgDeviceConnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"连接上"+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}

	@Override
	public void msgDeviceDisconnect(String deviceMac) {
		// TODO Auto-generated method stub
		Log.i(TAG,"断开了"+deviceMac);
		Message message = new Message();
		message.what = 1;
		handler.sendMessage(message);
	}
	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				refreshListView();
				break;
			default:
				break;
			}
		}

	};
	@Override
	protected void onStop() {
		super.onStop();

	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		btCommManager.disconnectDevice();
		System.exit(0);
	}

}
