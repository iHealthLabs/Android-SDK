package com.example.sdk_demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.jiuan.android.sdk.am.observer_comm.Interface_Observer_CommMsg_AM;
import com.jiuan.android.sdk.bg.observer.Interface_Observer_BGCoomMsg;
import com.jiuan.android.sdk.bp.observer_comm.Interface_Observer_CommMsg_BP;
import com.jiuan.android.sdk.device.DeviceManager;
import com.jiuan.android.sdk.hs.observer_comm.Interface_Observer_CommMsg_HS;
import com.jiuan.android.sdk.po.observer_comm.Interface_Observer_CommMsg_PO;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity implements Interface_Observer_BGCoomMsg,
	Interface_Observer_CommMsg_BP,
	Interface_Observer_CommMsg_AM, 
	Interface_Observer_CommMsg_HS,
	Interface_Observer_CommMsg_PO{

    private ListView mDeviceListview;
    private List<HashMap<String, String>> mDeviceList;
    private SimpleAdapter deviceSimpleAdapter;

	private String userId = "";
	private Button btn_bg1;
	private Button btn_scan;
	private DeviceManager deviceManager = DeviceManager.getInstance();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);
		
		userId = "userliujun_511222145893@jiuan.com";
		
		mDeviceList = new ArrayList<HashMap<String,String>>();
		deviceManager.initDeviceManager(this, userId);
		deviceManager.initReceiver();
		deviceManager.initAmStateCallback(this);
		deviceManager.initBgStateCallback(this);
		deviceManager.initBpStateCallback(this);
		deviceManager.initHsStateCallback(this);
		deviceManager.initPoStateCallaback(this);
		mDeviceListview = (ListView)findViewById(R.id.bg5list);
		
		btn_bg1 = (Button)findViewById(R.id.buttonbg1);
		btn_bg1.setVisibility(View.INVISIBLE);
		btn_bg1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this, BG1Activity.class);
				startActivity(intent);
			}
		});
		btn_scan = (Button) findViewById(R.id.btn_scan);
		btn_scan.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                    	deviceManager.scanDevice();
                    }
                }).start();
            }
        });
		
	}
	private void initListView(){
		if(mDeviceList != null){
			deviceSimpleAdapter = new SimpleAdapter(this, mDeviceList, R.layout.listview_baseview, 
				 new String[]{"type", "mac"},
				 new int[]{R.id.bgname, R.id.bgaddress});
			mDeviceListview.setAdapter(deviceSimpleAdapter);
			mDeviceListview.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					if(mDeviceList.get(position).get("type").equals("BG1")){
						deviceManager.cancelScanDevice();
						Intent intent = new Intent(MainActivity.this, BG1Activity.class);
						intent.putExtra("mac", mDeviceList.get(position).get("mac"));
						startActivity(intent);
					}else if(mDeviceList.get(position).get("type").equals("BG5")){
						deviceManager.cancelScanDevice();
	                    Intent intent = new Intent(MainActivity.this, BG5Activity.class);
	                    intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("BP3")){
	                	deviceManager.cancelScanDevice();
	                    Intent intent = new Intent(MainActivity.this, BP3Activity.class);
	                    intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("BP5")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, BP5Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("BP7")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, BP7Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("HS3")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Hs3Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("HS4")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Hs4Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("HS4S")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Hs4Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("HS5")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Hs5Activity_bt.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("HS5WIFI")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Hs5Activity_wifi.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("AM3")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, AM3Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("AM3S")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, AM3SActivity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }else if(mDeviceList.get(position).get("type").equals("PO3")){
	                	deviceManager.cancelScanDevice();
	                	Intent intent = new Intent(MainActivity.this, Po3Activity.class);
	                	intent.putExtra("mac", mDeviceList.get(position).get("mac"));
	                    startActivity(intent);
	                    return;
	                }
				}
			});
		}
	}
	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				map2List();
				initListView();
				break;
			case 2:
				btn_bg1.setVisibility(View.VISIBLE);
				break;
			case 3:
				btn_bg1.setVisibility(View.INVISIBLE);
				break;
			default:
				break;
			}
		}

	};
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	public void msgHeadsetPluIn() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 2;
		handler.sendMessage(message);
	}
	@Override
	public void msgHeadsetPullOut() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 3;
		handler.sendMessage(message);
	}

	@Override
	protected void onStop() {
		super.onStop();

	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.exit(0);
	}
    
	private List<HashMap<String, String>> map2List(){
		List<HashMap<String, String>> list = new ArrayList<HashMap<String,String>>();
		mDeviceList.clear();
		for (Iterator<String> it =  deviceMap.keySet().iterator();it.hasNext();){
		    Object key = it.next();
		    HashMap<String, String> map = new HashMap<String, String>();
	        map.put("type", deviceMap.get(key));
	        map.put("mac", (String)key);
	        mDeviceList.add(map);
		}
		return list;
	}
    private void refresh(){
    	 Message message = new Message();
	     message.what = 1;
	     handler.sendMessage(message);
    }
    
    private Map<String, String> deviceMap = new ConcurrentHashMap<String, String>();
	
    @Override
	public void msgDeviceConnect_Hs(String deviceMac, String deviceType) {
		deviceMap.put(deviceMac, deviceType);
		refresh();
	}
	
	@Override
	public void msgDeviceDisconnect_Hs(String deviceMac, String deviceType) {
		deviceMap.remove(deviceMac);
		refresh();
	}
	
	@Override
	public void msgDeviceConnect_Am(String deviceMac, String deviceType) {
		deviceMap.put(deviceMac, deviceType);
		refresh();
	}
	
	@Override
	public void msgDeviceDisconnect_Am(String deviceMac, String deviceType) {
		deviceMap.remove(deviceMac);
		refresh();
	}
	
	@Override
	public void msgDeviceConnect_Bp(String deviceMac, String deviceType) {
		deviceMap.put(deviceMac, deviceType);
		refresh();
	}
	
	@Override
	public void msgDeviceDisconnect_Bp(String deviceMac, String deviceType) {
		deviceMap.remove(deviceMac);
		refresh();
	}
	
	@Override
	public void msgDeviceConnect_Bg(String deviceMac, String deviceType) {
		deviceMap.put(deviceMac, deviceType);
		refresh();
	}
	
	@Override
	public void msgDeviceDisconnect_Bg(String deviceMac, String deviceType) {
		deviceMap.remove(deviceMac);
		refresh();
	}

	@Override
	public void msgDeviceConnect_Po(String deviceMac, String deviceType) {
		deviceMap.put(deviceMac, deviceType);
		refresh();
	}
	
	@Override
	public void msgDeviceDisconnect_Po(String deviceMac, String deviceType) {
		deviceMap.remove(deviceMac);
		refresh();
	}
}
