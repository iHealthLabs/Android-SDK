package com.example.sdk_demo;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.houxiyang.guitar.Utils.TunnerThread;
import com.jiuan.android.sdk.bg.audio.BG1Control;
import com.jiuan.android.sdk.bg.observer.Interface_Observer_BG;

public class BG1Activity extends Activity implements Interface_Observer_BG{

	AudioManager myAudio;
	BG1Control bg1Control;
	public TunnerThread tunner;
	
	private Button btn_connect;
	private TextView tv_msg_1;
	private TextView tv_msg_2;
	private TextView tv_msg_3;
	private TextView tv_msg_4;
	private TextView tv_msg_5;
	private TextView tv_msg_6;
	private TextView tv_msg_7;
	
	String qr = "02323C55324214322D1200A0297F60D464149172DF6219011CD90FCC0F9A";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bg1);
		
		myAudio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		bg1Control = new BG1Control();
		bg1Control.bg1Subject.attach(this);
		tunner = new TunnerThread();
		
		btn_connect = (Button)findViewById(R.id.button_connect);
		btn_connect.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new Thread() {
					public void run() {
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						/**
						 * userId the identification of the user, could be the form of email address or mobile phone number
						 * (mobile phone number is not supported temporarily).
						 * clientID and clientSecret, as the identification of the SDK, 
						 * will be issued after the iHealth SDK registration. 
						 * please contact lvjincan@jiuan.com for registration.
						 */
						String userId = "";
						final String clientID = "";
						final String clientSecret = "";
						bg1Control.connect(BG1Activity.this, userId, clientID, clientSecret);
					}
				}.start();
			}
		});
		
		tv_msg_1 = (TextView)findViewById(R.id.textView_bg1_1);
		tv_msg_2 = (TextView)findViewById(R.id.textView_bg1_2);
		tv_msg_3 = (TextView)findViewById(R.id.textView_bg1_3);
		tv_msg_4 = (TextView)findViewById(R.id.textView_bg1_4);
		tv_msg_5 = (TextView)findViewById(R.id.textView_bg1_5);
		tv_msg_6 = (TextView)findViewById(R.id.textView_bg1_6);
		tv_msg_7 = (TextView)findViewById(R.id.textView_bg1_7);
	}
	private void connectDevice() {
		if(bg1Control.identify(qr)){
			Message message = new Message();
			message.what = 1;
			handler.sendMessage(message);
		}else{
			Message message = new Message();
			message.what = 2;
			handler.sendMessage(message);
		}
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		myAudio.setStreamVolume(AudioManager.STREAM_MUSIC, 16,1);
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		bg1Control.close();
	}

	@Override
	public void msgBGError(int num) {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","error:"+num);
		message.obj = bundle;
		handler.sendMessage(message);
	}

	@Override
	public void msgBGStripIn() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","strip in");
		message.obj = bundle;
		handler.sendMessage(message);
	}

	@Override
	public void msgBGGetBlood() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","got blood");
		message.obj = bundle;
		handler.sendMessage(message);
	}

	@Override
	public void msgBGStripOut() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","strip out");
		message.obj = bundle;
		handler.sendMessage(message);
	}

	@Override
	public void msgBGResult(int result) {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","result:"+result);
		message.obj = bundle;
		handler.sendMessage(message);
	}

	@Override
	public void msgBGPowerOff() {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = 7;
		Bundle bundle = new Bundle();
		bundle.putString("result","bg1 poweroff");
		message.obj = bundle;
		handler.sendMessage(message);
	}
	/**
	 * UI handler
	 */
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				Toast.makeText(getApplicationContext(), "bg1 identify success", Toast.LENGTH_SHORT).show();
				tv_msg_2.setText("bg1 identify success");
				break;
			case 2:
				Toast.makeText(getApplicationContext(), "bg1 identify fail", Toast.LENGTH_SHORT).show();
				tv_msg_2.setText("bg1 identify fail");
				break;
			case 3:
				tv_msg_3.setText("user identify success");
				break;
			case 4:
				tv_msg_3.setText("user identify fail");
				break;
			case 7:
				Bundle bundle = (Bundle)msg.obj;
				String result = bundle.getString("result");
				tv_msg_1.setText(result);
				break;
			default:
				break;
			}
		}
	};
	@Override
	public void msgUserStatus(int status) {
		// TODO Auto-generated method stub
		Log.i("", "status "+status);
		if(status == 1||status == 2||status == 3||status == 4){
			Message message = new Message();
			message.what = 3;
			handler.sendMessage(message);
			new Thread(){
				public void run(){
					connectDevice();					
				}
			}.start();
		}else{
			Message message = new Message();
			message.what = 4;
			handler.sendMessage(message);
		}
	}
}
