
package com.example.sdk_demo;

import com.jiuan.android.sdk.device.DeviceManager;
import com.jiuan.android.sdk.po.bluetooth.lpcbt.JiuanPO3Observer;
import com.jiuan.android.sdk.po.bluetooth.lpcbt.PO3Control;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Po3Activity extends Activity implements JiuanPO3Observer {
    private PO3Control poControl;

    private Button btn_connect;
    private Button btn_bettary;
    private Button btn_history, btn_realdata;

    private DeviceManager deviceManager;
    private String mAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_po3);

        // get control by device mac
        deviceManager = DeviceManager.getInstance();
        mAddress = getIntent().getStringExtra("mac");
        if (deviceManager.getAmDevice(mAddress) instanceof PO3Control) {
            poControl = (PO3Control) deviceManager.getPoDevice(mAddress);
        }

        if (poControl != null) {
            poControl.addObserver(this);
        }

        initView();
    }

    private void initView() {
        btn_connect = (Button) findViewById(R.id.connect);
        btn_connect.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                /**
                 * userId, the identification of the user, could be the form of email address or
                 * mobile phone number (mobile phone number is not supported temporarily). clientID
                 * and clientSecret, as the identification of the SDK, will be issued after the
                 * iHealth SDK registration. please contact lvjincan@jiuan.com for registration.
                 */
                String userId = "";
                final String clientID = "";
                final String clientSecret = "";
                poControl.connect(Po3Activity.this, userId, clientID, clientSecret);
            }
        });

        btn_bettary = (Button) findViewById(R.id.bettary);
        btn_bettary.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                poControl.getBattery();
            }
        });
        btn_history = (Button) findViewById(R.id.history);
        btn_history.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                poControl.syncHistoryDatas();
            }
        });
        btn_realdata = (Button) findViewById(R.id.realdata);
        btn_realdata.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                poControl.startRealTime();
            }
        });

    }

    private Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    int userStatus = ((Bundle) (msg.obj)).getInt("status");
                    Toast.makeText(getApplicationContext(), "PO3 UserStatus=" + userStatus, Toast.LENGTH_SHORT).show();
                    break;
                case 1:
                    int battery = ((Bundle) (msg.obj)).getInt("battery");
                    Toast.makeText(getApplicationContext(), "PO3 battery=" + battery, Toast.LENGTH_SHORT).show();
                    break;
                case 2:
                    String historyData = ((Bundle) (msg.obj)).getString("historyData");
                    Toast.makeText(getApplicationContext(), "PO3 historyData=" + historyData, Toast.LENGTH_SHORT)
                            .show();
                    break;
                case 3:
                    String result = ((Bundle) (msg.obj)).getString("result");
                    Toast.makeText(getApplicationContext(), "PO3 result=" + result, Toast.LENGTH_SHORT).show();
                    break;
                case 4:

                    Toast.makeText(getApplicationContext(), "no historyData", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }

    };

    @Override
    public void msgUserStatus(int status) {
        // TODO Auto-generated method stub
        Log.i("act", "user status" + status);
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putInt("status", status);
        msg.what = 0;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }

    @Override
    public void msgBattery(int battery) {
        // TODO Auto-generated method stub
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putInt("battery", battery);
        msg.what = 1;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }

    @Override
    public void msgHistroyData(String historyData) {
        // TODO Auto-generated method stub
        if (historyData == null) {
            Log.d("history", "no historyData");
            handler.sendEmptyMessage(4);
            /**
             * There is no historical data
             */
        } else {
            Log.i("history", historyData);
            Message msg = new Message();
            Bundle bundle = new Bundle();
            bundle.putString("historyData", historyData);
            msg.what = 2;
            msg.obj = bundle;
            handler.sendMessage(msg);
        }

    }

    @Override
    public void msgRealtimeData(String realData) {
        // TODO Auto-generated method stub
        Log.i("real", realData);
    }

    @Override
    public void msgResultData(String result) {
        // TODO Auto-generated method stub
        Log.i("end", result);
        Message msg = new Message();
        Bundle bundle = new Bundle();
        bundle.putString("result", result);
        msg.what = 3;
        msg.obj = bundle;
        handler.sendMessage(msg);
    }
}
